
import boto3

def lambda_handler(event, context):
    ssm = boto3.client('ssm')
    response = ssm.get_parameter(Name='/app/config/api_key', WithDecryption=True)
    return {
        'statusCode': 200,
        'body': f"Parameter value is: {response['Parameter']['Value']}"
    }
